package estructuras;

import modelos.Empleado;

public class ListaLigada {
    private Nodo cabeza;

    // Ya no es necesario declarar una clase interna Nodo,
    // porque ahora usamos la clase pública Nodo de estructuras.Nodo

    public void insertarOrdenado(Empleado emp) {
        Nodo nuevo = new Nodo(emp);
        if (cabeza == null || emp.getNombreCompleto().compareToIgnoreCase(cabeza.dato.getNombreCompleto()) < 0) {
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.siguiente != null &&
                    emp.getNombreCompleto().compareToIgnoreCase(actual.siguiente.dato.getNombreCompleto()) > 0) {
                actual = actual.siguiente;
            }
            nuevo.siguiente = actual.siguiente;
            actual.siguiente = nuevo;
        }
    }

    public Nodo getCabeza() {
        return cabeza;
    }

    public Empleado eliminarPorID(String id) {
        if (cabeza == null) return null;

        if (cabeza.dato.getId().equals(id)) {
            Empleado eliminado = cabeza.dato;
            cabeza = cabeza.siguiente;
            return eliminado;
        }

        Nodo actual = cabeza;
        while (actual.siguiente != null && !actual.siguiente.dato.getId().equals(id)) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            Empleado eliminado = actual.siguiente.dato;
            actual.siguiente = actual.siguiente.siguiente;
            return eliminado;
        }

        return null;
    }

    public Empleado buscarPorID(String id) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato.getId().equals(id)) {
                return actual.dato;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void imprimirLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }

    public int tamaño() {
        int contador = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }
        return contador;
    }
}


