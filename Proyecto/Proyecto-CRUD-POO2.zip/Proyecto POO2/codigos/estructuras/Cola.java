
package estructuras;

import java.util.LinkedList;
import java.util.Queue;

public class Cola {
    private Queue<String> cola = new LinkedList<>();

    // Encolar un elemento (agregar al final)
    public void encolar(String id) {
        cola.add(id);
    }

    // Desencolar un elemento (sacar el primero)
    public String desencolar() {
        return cola.poll();  // Devuelve null si está vacía
    }

    // Ver el primer elemento sin sacarlo
    public String frente() {
        return cola.peek();  // Devuelve null si está vacía
    }

    // Saber si la cola está vacía
    public boolean estaVacia() {
        return cola.isEmpty();
    }

    // Obtener el tamaño de la cola
    public int tamaño() {
        return cola.size();
    }

    // Limpiar toda la cola
    public void limpiar() {
        cola.clear();
    }

    // Obtener la cola (solo para lectura, cuidado con modificarla directamente)
    public Queue<String> getCola() {
        return cola;
    }
}

