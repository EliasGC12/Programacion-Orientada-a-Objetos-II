
package estructuras;

import modelos.Empleado;
import java.util.Stack;

public class Pila {
    private Stack<Empleado> pila = new Stack<>();

    // Agrega un empleado a la pila (push)
    public void push(Empleado emp) {
        pila.push(emp);
    }

    // Saca y devuelve el empleado en la cima de la pila (pop), o null si está vacía
    public Empleado pop() {
        return pila.isEmpty() ? null : pila.pop();
    }

    // Mira el empleado en la cima sin sacarlo (peek)
    public Empleado peek() {
        return pila.isEmpty() ? null : pila.peek();
    }

    // Verifica si la pila está vacía
    public boolean estaVacia() {
        return pila.isEmpty();
    }

    // Retorna el tamaño actual de la pila
    public int tamaño() {
        return pila.size();
    }

    // Limpia toda la pila
    public void limpiar() {
        pila.clear();
    }

    // Devuelve la pila (cuidado con modificarla directamente)
    public Stack<Empleado> getPila() {
        return pila;
    }
}
