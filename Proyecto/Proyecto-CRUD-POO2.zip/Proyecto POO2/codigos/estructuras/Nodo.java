// Archivo: Nodo.java
package estructuras;

import modelos.Empleado;

public class Nodo {
    public Empleado dato;
    public Nodo siguiente;

    public Nodo(Empleado dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}


