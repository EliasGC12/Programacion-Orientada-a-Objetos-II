package interfaz;

import javax.swing.*;
import java.awt.event.*;
import estructuras.ListaLigada;
import estructuras.Pila;
import estructuras.Nodo;
import modelos.Empleado;
import persistencia.ArchivoEmpleado;

public class EliminarEmpleado extends JFrame {
    private JTextField campoID;
    private JButton eliminarBtn;
    private ListaLigada lista;
    private Pila pila;

    public EliminarEmpleado(ListaLigada lista, Pila pila) {
        this.lista = lista;
        this.pila = pila;

        setTitle("Eliminar Empleado");
        setSize(350, 150);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JLabel lblID = new JLabel("ID del Empleado a eliminar:");
        lblID.setBounds(20, 20, 200, 25);
        add(lblID);

        campoID = new JTextField();
        campoID.setBounds(180, 20, 130, 25);
        add(campoID);

        eliminarBtn = new JButton("Eliminar");
        eliminarBtn.setBounds(110, 60, 120, 30);
        add(eliminarBtn);

        eliminarBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = campoID.getText();
                Empleado eliminado = lista.eliminarPorID(id);
                if (eliminado != null) {
                    pila.push(eliminado);
                    ArchivoEmpleado.reescribirArchivo(lista);
                    JOptionPane.showMessageDialog(null, "Empleado eliminado y guardado en historial.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Empleado no encontrado.");
                }
            }
        });
    }
}

