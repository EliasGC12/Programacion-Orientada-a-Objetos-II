package interfaz;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class Login extends JFrame {
    private JTextField correo;
    private JPasswordField password;
    private JButton iniciar, registrar;

    private final String ARCHIVO_USUARIOS = "usuarios.txt";

    public Login() {
        setTitle("Login de Administrador");
        setSize(350, 220);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null); // Centrar la ventana

        verificarArchivoUsuarios(); // ✅ Crea el archivo si no existe

        JLabel lblUsuario = new JLabel("Correo electrónico:");
        lblUsuario.setBounds(20, 20, 150, 25);
        add(lblUsuario);

        correo = new JTextField();
        correo.setBounds(160, 20, 150, 25);
        add(correo);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(20, 60, 150, 25);
        add(lblPass);

        password = new JPasswordField();
        password.setBounds(160, 60, 150, 25);
        add(password);

        iniciar = new JButton("Iniciar Sesión");
        iniciar.setBounds(30, 110, 130, 30);
        add(iniciar);

        registrar = new JButton("Registrarse");
        registrar.setBounds(180, 110, 130, 30);
        add(registrar);

        iniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String user = correo.getText();
                String pass = new String(password.getPassword());

                if (validarCredenciales(user, pass)) {
                    dispose();
                    new MenuPrincipal().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Correo o contraseña incorrectos.");
                }
            }
        });

        registrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentanaRegistro();
            }
        });
    }

    private void verificarArchivoUsuarios() {
        File archivo = new File(ARCHIVO_USUARIOS);
        if (!archivo.exists()) {
            try {
                archivo.createNewFile();
                System.out.println("Archivo 'usuarios.txt' creado correctamente.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al crear archivo de usuarios.");
                e.printStackTrace();
            }
        }
    }

    private void abrirVentanaRegistro() {
        JDialog dialogo = new JDialog(this, "Registro de Nuevo Usuario", true);
        dialogo.setSize(350, 200);
        dialogo.setLayout(null);
        dialogo.setLocationRelativeTo(this);

        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(20, 20, 150, 25);
        dialogo.add(lblCorreo);

        JTextField txtNuevoCorreo = new JTextField();
        txtNuevoCorreo.setBounds(160, 20, 150, 25);
        dialogo.add(txtNuevoCorreo);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(20, 60, 150, 25);
        dialogo.add(lblPass);

        JPasswordField txtNuevaPass = new JPasswordField();
        txtNuevaPass.setBounds(160, 60, 150, 25);
        dialogo.add(txtNuevaPass);

        JButton btnGuardar = new JButton("Registrar");
        btnGuardar.setBounds(100, 110, 130, 30);
        dialogo.add(btnGuardar);

        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nuevoCorreo = txtNuevoCorreo.getText();
                String nuevaPass = new String(txtNuevaPass.getPassword());

                if (!nuevoCorreo.isEmpty() && !nuevaPass.isEmpty()) {
                    guardarUsuario(nuevoCorreo, nuevaPass);
                    JOptionPane.showMessageDialog(dialogo, "Usuario registrado correctamente.");
                    dialogo.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialogo, "Complete todos los campos.");
                }
            }
        });

        dialogo.setVisible(true);
    }

    private void guardarUsuario(String correo, String pass) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO_USUARIOS, true))) {
            bw.write(correo + "," + pass);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean validarCredenciales(String correo, String pass) {
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2 && partes[0].equals(correo) && partes[1].equals(pass)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}


