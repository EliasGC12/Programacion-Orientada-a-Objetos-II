
package interfaz;

import javax.swing.*;
import modelos.Empleado;
import estructuras.ListaLigada;
import persistencia.ArchivoEmpleado;

import java.awt.event.*;

public class PanelEmpleado extends JFrame {
    JTextField id, nombre, apPat, apMat, sexo, edad, direccion, telefono, puesto, depto, horas, costo;
    JButton registrar;
    ListaLigada lista;

    public PanelEmpleado(ListaLigada lista) {
        this.lista = lista;

        setTitle("Registrar Empleado");
        setSize(400, 500);
        setLayout(null);

        JLabel l1 = new JLabel("ID:");
        l1.setBounds(20, 20, 100, 20);
        add(l1);
        id = new JTextField(); id.setBounds(150, 20, 200, 20); add(id);

        JLabel l2 = new JLabel("Nombre:");
        l2.setBounds(20, 50, 100, 20);
        add(l2);
        nombre = new JTextField(); nombre.setBounds(150, 50, 200, 20); add(nombre);

        JLabel l3 = new JLabel("Apellido Paterno:");
        l3.setBounds(20, 80, 120, 20);
        add(l3);
        apPat = new JTextField(); apPat.setBounds(150, 80, 200, 20); add(apPat);

        JLabel l4 = new JLabel("Apellido Materno:");
        l4.setBounds(20, 110, 120, 20);
        add(l4);
        apMat = new JTextField(); apMat.setBounds(150, 110, 200, 20); add(apMat);

        JLabel l5 = new JLabel("Sexo:");
        l5.setBounds(20, 140, 100, 20);
        add(l5);
        sexo = new JTextField(); sexo.setBounds(150, 140, 200, 20); add(sexo);

        JLabel l6 = new JLabel("Edad:");
        l6.setBounds(20, 170, 100, 20);
        add(l6);
        edad = new JTextField(); edad.setBounds(150, 170, 200, 20); add(edad);

        JLabel l7 = new JLabel("Dirección:");
        l7.setBounds(20, 200, 100, 20);
        add(l7);
        direccion = new JTextField(); direccion.setBounds(150, 200, 200, 20); add(direccion);

        JLabel l8 = new JLabel("Teléfono:");
        l8.setBounds(20, 230, 100, 20);
        add(l8);
        telefono = new JTextField(); telefono.setBounds(150, 230, 200, 20); add(telefono);

        JLabel l9 = new JLabel("Puesto:");
        l9.setBounds(20, 260, 100, 20);
        add(l9);
        puesto = new JTextField(); puesto.setBounds(150, 260, 200, 20); add(puesto);

        JLabel l10 = new JLabel("Departamento:");
        l10.setBounds(20, 290, 100, 20);
        add(l10);
        depto = new JTextField(); depto.setBounds(150, 290, 200, 20); add(depto);

        JLabel l11 = new JLabel("Horas Trabajadas:");
        l11.setBounds(20, 320, 120, 20);
        add(l11);
        horas = new JTextField(); horas.setBounds(150, 320, 200, 20); add(horas);

        JLabel l12 = new JLabel("Costo por Hora:");
        l12.setBounds(20, 350, 120, 20);
        add(l12);
        costo = new JTextField(); costo.setBounds(150, 350, 200, 20); add(costo);

        registrar = new JButton("Registrar");
        registrar.setBounds(130, 400, 120, 30);
        add(registrar);

        registrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Empleado emp = new Empleado(
                    id.getText(), nombre.getText(), apPat.getText(), apMat.getText(), sexo.getText(),
                    Integer.parseInt(edad.getText()), direccion.getText(), telefono.getText(),
                    puesto.getText(), depto.getText(), Integer.parseInt(horas.getText()),
                    Double.parseDouble(costo.getText())
                );
                lista.insertarOrdenado(emp);
                ArchivoEmpleado.guardarEmpleado(emp);
                JOptionPane.showMessageDialog(null, "Empleado registrado correctamente.");
                dispose();
            }
        });
    }
}
