package interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import estructuras.Cola;

import java.util.Queue;

public class ColaEdiciones extends JFrame {
    public ColaEdiciones(Cola cola) {
        setTitle("Cola de Ediciones Pendientes");
        setSize(400, 250);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnas = { "ID Empleado Editado" };
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        JTable tabla = new JTable(modelo);

        Queue<String> colaActual = cola.getCola();

        for (String id : colaActual) {
            modelo.addRow(new Object[]{ id });
        }

        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll);
    }
}

