package interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelos.Empleado;
import estructuras.Pila;

import java.util.Stack;

public class HistorialEliminados extends JFrame {
    public HistorialEliminados(Pila pila) {
        setTitle("Historial de Eliminaciones");
        setSize(800, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnas = {
                "ID", "Nombre", "Apellido Paterno", "Apellido Materno", "Puesto", "Departamento", "Sueldo"
        };

        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        JTable tabla = new JTable(modelo);

        Stack<Empleado> pilaActual = pila.getPila();

        for (int i = pilaActual.size() - 1; i >= 0; i--) {
            Empleado emp = pilaActual.get(i);
            modelo.addRow(new Object[]{
                    emp.getId(), emp.getNombre(), emp.getApPaterno(), emp.getApMaterno(),
                    emp.getPuesto(), emp.getDepartamento(), emp.getSueldo()
            });
        }

        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll);
    }
}

