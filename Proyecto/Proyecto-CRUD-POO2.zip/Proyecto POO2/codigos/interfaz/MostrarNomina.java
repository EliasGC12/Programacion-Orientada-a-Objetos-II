package interfaz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelos.Empleado;
import estructuras.ListaLigada;
import estructuras.Nodo;

public class MostrarNomina extends JFrame {
    public MostrarNomina(ListaLigada lista) {
        setTitle("Nómina de Empleados");
        setSize(800, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] columnas = {
                "ID", "Nombre", "Apellido Paterno", "Apellido Materno", "Sexo", "Edad",
                "Dirección", "Teléfono", "Puesto", "Departamento", "Horas", "Costo/Hora", "Sueldo"
        };

        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        JTable tabla = new JTable(modelo);

        Nodo actual = lista.getCabeza();
        while (actual != null) {
            Empleado emp = actual.dato;
            modelo.addRow(new Object[]{
                    emp.getId(), emp.getNombre(), emp.getApPaterno(), emp.getApMaterno(), emp.getSexo(),
                    emp.getEdad(), emp.getDireccion(), emp.getTelefono(), emp.getPuesto(), emp.getDepartamento(),
                    emp.getHorasTrabajadas(), emp.getCostoHora(), emp.getSueldo()
            });
            actual = actual.siguiente;
        }

        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll);
    }
}

