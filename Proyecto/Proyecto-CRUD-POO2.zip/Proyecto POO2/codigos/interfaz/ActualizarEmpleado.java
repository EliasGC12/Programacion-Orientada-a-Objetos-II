package interfaz;

import javax.swing.*;
import java.awt.event.*;
import modelos.Empleado;
import estructuras.ListaLigada;
import estructuras.Cola;
import persistencia.ArchivoEmpleado;

public class ActualizarEmpleado extends JFrame {
    private JTextField campoID, nuevoTelefono, nuevoPuesto;
    private JButton buscarBtn, actualizarBtn;
    private ListaLigada lista;
    private Cola cola;

    public ActualizarEmpleado(ListaLigada lista, Cola cola) {
        this.lista = lista;
        this.cola = cola;

        setTitle("Actualizar Empleado");
        setSize(400, 250);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JLabel lblID = new JLabel("ID del Empleado:");
        lblID.setBounds(20, 20, 150, 25);
        add(lblID);

        campoID = new JTextField();
        campoID.setBounds(170, 20, 180, 25);
        add(campoID);

        buscarBtn = new JButton("Buscar");
        buscarBtn.setBounds(140, 60, 100, 30);
        add(buscarBtn);

        JLabel lblTel = new JLabel("Nuevo Teléfono:");
        lblTel.setBounds(20, 100, 150, 25);
        add(lblTel);

        nuevoTelefono = new JTextField();
        nuevoTelefono.setBounds(170, 100, 180, 25);
        add(nuevoTelefono);
        nuevoTelefono.setEnabled(false);

        JLabel lblPuesto = new JLabel("Nuevo Puesto:");
        lblPuesto.setBounds(20, 130, 150, 25);
        add(lblPuesto);

        nuevoPuesto = new JTextField();
        nuevoPuesto.setBounds(170, 130, 180, 25);
        add(nuevoPuesto);
        nuevoPuesto.setEnabled(false);

        actualizarBtn = new JButton("Actualizar");
        actualizarBtn.setBounds(140, 170, 120, 30);
        actualizarBtn.setEnabled(false);
        add(actualizarBtn);

        buscarBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = campoID.getText();
                Empleado empleado = lista.buscarPorID(id);
                if (empleado != null) {
                    nuevoTelefono.setText(empleado.getTelefono());
                    nuevoPuesto.setText(empleado.getPuesto());
                    nuevoTelefono.setEnabled(true);
                    nuevoPuesto.setEnabled(true);
                    actualizarBtn.setEnabled(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Empleado no encontrado.");
                }
            }
        });

        actualizarBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = campoID.getText();
                Empleado empleado = lista.buscarPorID(id);
                if (empleado != null) {
                    empleado.setTelefono(nuevoTelefono.getText());
                    empleado.setPuesto(nuevoPuesto.getText());
                    // Aquí puedes agregar código para guardar los cambios en archivo o actualizar estructura
                    JOptionPane.showMessageDialog(null, "Empleado actualizado correctamente.");
                    nuevoTelefono.setEnabled(false);
                    nuevoPuesto.setEnabled(false);
                    actualizarBtn.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(null, "Error al actualizar. Empleado no encontrado.");
                }
            }
        });
    }
}


