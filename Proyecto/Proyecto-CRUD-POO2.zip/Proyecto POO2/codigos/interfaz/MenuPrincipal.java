package interfaz;

import javax.swing.*;
import java.awt.event.*;
import estructuras.ListaLigada;
import estructuras.Pila;
import estructuras.Cola;

public class MenuPrincipal extends JFrame {
    ListaLigada lista;
    Pila pila;
    Cola cola;

    public MenuPrincipal() {
        setTitle("Sistema de Nómina - Menú Principal");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        lista = new ListaLigada();
        pila = new Pila();
        cola = new Cola();

        // Botón: Registrar empleado
        JButton btnRegistrar = new JButton("Registrar Empleado");
        btnRegistrar.setBounds(100, 30, 200, 30);
        add(btnRegistrar);

        // Botón: Mostrar nómina
        JButton btnMostrar = new JButton("Mostrar Nómina");
        btnMostrar.setBounds(100, 70, 200, 30);
        add(btnMostrar);

        // Botón: Actualizar empleado
        JButton btnActualizar = new JButton("Actualizar Empleado");
        btnActualizar.setBounds(100, 110, 200, 30);
        add(btnActualizar);

        // Botón: Eliminar empleado
        JButton btnEliminar = new JButton("Eliminar Empleado");
        btnEliminar.setBounds(100, 150, 200, 30);
        add(btnEliminar);

        // Botón: Ver historial de eliminados
        JButton btnHistorial = new JButton("Historial Eliminados");
        btnHistorial.setBounds(100, 190, 200, 30);
        add(btnHistorial);

        // Botón: Ver cola de ediciones
        JButton btnCola = new JButton("Cola de Ediciones");
        btnCola.setBounds(100, 230, 200, 30);
        add(btnCola);

        // Botón: Cerrar sesión
        JButton btnCerrar = new JButton("Cerrar Sesión");
        btnCerrar.setBounds(100, 270, 200, 30);
        add(btnCerrar);

        // Acción: Registrar
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new PanelEmpleado(lista).setVisible(true);
            }
        });

        // Acción: Mostrar nómina
        btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MostrarNomina(lista).setVisible(true);
            }
        });

        // Acción: Actualizar empleado
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ActualizarEmpleado(lista, cola).setVisible(true);
            }
        });

        // Acción: Eliminar empleado
        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new EliminarEmpleado(lista, pila).setVisible(true);
            }
        });

        // Acción: Ver historial
        btnHistorial.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HistorialEliminados(pila).setVisible(true);
            }
        });

        // Acción: Ver cola
        btnCola.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ColaEdiciones(cola).setVisible(true);
            }
        });

        // Acción: Cerrar sesión
        btnCerrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login().setVisible(true);
            }
        });
    }
}

