
import interfaz.Login;

public class Main {
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}
