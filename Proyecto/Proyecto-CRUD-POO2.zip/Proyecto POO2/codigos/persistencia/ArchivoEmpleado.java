
package persistencia;

import estructuras.ListaLigada;
import estructuras.Nodo;
import modelos.Empleado;
import java.io.*;
import java.util.ArrayList;

public class ArchivoEmpleado {
    private static final String RUTA_ARCHIVO = "empleados.txt";

    public static void guardarEmpleado(Empleado emp) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_ARCHIVO, true))) {
            bw.write(emp.toString());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Empleado> cargarEmpleados() {
        ArrayList<Empleado> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                Empleado emp = new Empleado(
                    datos[0], datos[1], datos[2], datos[3], datos[4],
                    Integer.parseInt(datos[5]), datos[6], datos[7], datos[8],
                    datos[9], Integer.parseInt(datos[10]), Double.parseDouble(datos[11])
                );
                lista.add(emp);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static void reescribirArchivo(ListaLigada lista) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_ARCHIVO))) {
            Nodo actual = lista.getCabeza();
            while (actual != null) {
                Empleado emp = actual.dato;
                // Aquí defines el formato de escritura, por ejemplo: ID,Nombre,Teléfono,Puesto
                String linea = emp.getId() + "," + emp.getNombreCompleto() + "," + emp.getTelefono() + "," + emp.getPuesto();
                bw.write(linea);
                bw.newLine();
                actual = actual.siguiente;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
