package modelos;

public class Empleado {
    private String id;
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String sexo;
    private int edad;
    private String direccion;
    private String telefono;
    private String puesto;
    private String departamento;
    private int horasTrabajadas;
    private double costoHora;
    private double sueldo;

    public Empleado(String id, String nombre, String apPaterno, String apMaterno, String sexo,
                    int edad, String direccion, String telefono, String puesto, String departamento,
                    int horasTrabajadas, double costoHora) {
        this.id = id;
        this.nombre = nombre;
        this.apPaterno = apPaterno;
        this.apMaterno = apMaterno;
        this.sexo = sexo;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
        this.puesto = puesto;
        this.departamento = departamento;
        this.horasTrabajadas = horasTrabajadas;
        this.costoHora = costoHora;
        this.sueldo = horasTrabajadas * costoHora;
    }

    // Getters
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApPaterno() { return apPaterno; }
    public String getApMaterno() { return apMaterno; }
    public String getSexo() { return sexo; }
    public int getEdad() { return edad; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public String getPuesto() { return puesto; }
    public String getDepartamento() { return departamento; }
    public int getHorasTrabajadas() { return horasTrabajadas; }
    public double getCostoHora() { return costoHora; }
    public double getSueldo() { return sueldo; }

    // Setters (solo para los campos que se actualizan)
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    // Para insertar ordenado alfabéticamente por nombre completo
    public String getNombreCompleto() {
        return nombre + " " + apPaterno + " " + apMaterno;
    }

    // Para guardar en archivo .txt
    @Override
    public String toString() {
        return id + "," + nombre + "," + apPaterno + "," + apMaterno + "," + sexo + "," +
                edad + "," + direccion + "," + telefono + "," + puesto + "," + departamento + "," +
                horasTrabajadas + "," + costoHora + "," + sueldo;
    }
}

